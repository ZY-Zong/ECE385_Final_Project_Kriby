
#ifndef USB_MAIN_H_
#define USB_MAIN_H_

void usb_initialize();
int get_keycode_value();

#endif /* USB_MAIN_H_ */